/**
 * Created by lifeng on 15/4/17.
 */
/* Controllers */

var boxControllers = angular.module('boxControllers', [
    'ui.router'
]);

boxControllers.controller('IndexCtrl', ['$scope', '$state',
    function($scope, $state) {
        $state.title="盒子";
    }]);


boxControllers.controller('HomeCtrl', ['$scope', '$state',
    function($scope, $state) {
        $state.title="盒子";
    }]);

boxControllers.controller('MesCtrl', ['$scope', '$state',
    function($scope, $state) {
        $state.title="消息";
    }]);

//提醒
boxControllers.controller('AlertCtrl', ['$scope', '$state',
    function($scope, $state) {
        $state.title="提醒";
        $state.go('alert.yy');
    }]);

//添加用药提醒
boxControllers.controller('AlertAddYYCtrl', ['$scope', '$state',
    function($scope, $state) {
        $state.title="提醒";
    }]);


boxControllers.controller('SetCtrl',['$scope', '$state',
    function($scope, $state){
        $state.title="设置";
    }
])   //更多